#include<iostream>
#include"List.h"

using namespace std;

/* NO USE,just for test
Node* creatList()
{
	Node* header = new Node;
	header->val = NULL;
	header->next = nullptr;
	Node* pCurrent = header;
	int val;


	while (true)
	{
		cout << "Val = "; cin >> val;
		if (val == 0) break;


		Node* newNode = new Node;
		newNode->val = val;
		newNode->next = nullptr;


		pCurrent->next = newNode;
		pCurrent = newNode;
	}
	return header;
}
*/


int main()
{
	List test,test1,test2,test3,test4;
	for (int i = 1; i < 10; i++)
	{
		test += i;
	}
	for (int i = 2; i < 20; i+=2)
	{
		test1 += i;
	}
	test.select();
	test1.select();

	cout << "test	"<<test<<endl << endl;
	cout << "test size: " << test.size << endl;
	cout << "----------------------------------------------------------------------------------------------------\n";
	cout << "test1	" << test1 << endl << endl;
	cout << "test1 size: " << test1.size << endl;
	cout << "----------------------------------------------------------------------------------------------------\n";

	test2 =  test & test1;
	//test2.select();
	cout << "test2 =  test & test1\n test2: " << test2 << endl << endl;
	cout << "test2 size: " << test2.size << endl;
	cout << "----------------------------------------------------------------------------------------------------\n";

	test3 = test | test1;
	//test3.select();
	cout << "test3 = test | test1\n test3: " << test3 << endl << endl;
	cout << "test3 size: " << test3.size << endl;
	cout << "----------------------------------------------------------------------------------------------------\n";

	test.merge(test1);
	cout << "test.merge(test1) : " << test << endl;
	cout << "test size: " << test.size << endl;
	cout << "----------------------------------------------------------------------------------------------------\n";


	return 0;
}
