#include"Exception2.h"		//this is list
#include<iostream>
//#include"DobLinList.h"	//this is double linked list

bool testBalanceBrackets(const char* text, int maxDeep = 30)
{

	StackArray<char>* stack = new StackArray<char>(maxDeep);

	bool isBalanceBrackets = true; 

	try {
		char cText = '\0';   

		for (int i = 0; ((cText = text[i]) != '\0') && (isBalanceBrackets == true); i++) {

			switch (cText) {

			case '(': case '[': case '{':

				stack->push(cText);    
				break;

			case ')': 
				if (stack->pop() != '(') {
					isBalanceBrackets = false;
				}
				break;

			case ']':
				if (stack->pop() != '[') {
					isBalanceBrackets = false;
				}
				break;

			case '}':
				if (stack->pop() != '{') {
					isBalanceBrackets = false;
				}
				break;
			}
		}
		isBalanceBrackets = isBalanceBrackets && stack->isEmpty();

	}
	catch (StackUnderflow) {
		isBalanceBrackets = false;     
	}

	catch (StackOverflow) {
		isBalanceBrackets = false; 
	}

	delete stack;

	return isBalanceBrackets;

}


//for list stack
bool test(const char* text, int maxDeep = 30)
{

	Stack<char>* stack = new Stack<char>;

	bool isBalanceBrackets = true; 
	try {
		char cText = '\0';    

		for (int i = 0; ((cText = text[i]) != '\0') && (isBalanceBrackets == true); i++) {

			switch (cText) {

			case '(': case '[': case '{':

				stack->push(cText);    
				break;

			case ')': 
				if (stack->pop() != '(') {
					isBalanceBrackets = false;
				}
				break;

			case ']':
				if (stack->pop() != '[') {
					isBalanceBrackets = false;
				}
				break;

			case '}':
				if (stack->pop() != '{') {
					isBalanceBrackets = false;
				}
				break;
			}
		}
		isBalanceBrackets = isBalanceBrackets && stack->isEmpty();

	}

	catch (StackUnderflow) {
		isBalanceBrackets = false;
	}
	catch (StackOverflow) {
		isBalanceBrackets = false;  
	}

	delete stack;

	return isBalanceBrackets;

}

using namespace std;
int main()
{
	
	

	const char* text00 = " ok ";
	cout << text00 << ": " << (testBalanceBrackets(text00) ? "right" : "wrong") << endl;
	cout << text00 << ": " << (test(text00) ? "right" : "wrong") << endl;
	

	const char* text01 = "(  )  ok ";
	cout << text01 << ": " << (testBalanceBrackets(text01) ? "right" : "wrong") << endl;
	cout << text01 << ": " << (test(text01) ? "right" : "wrong") << endl;

	const char* text02 = "( ( [] ) )  ok ";
	cout << text02 << ": " << (testBalanceBrackets(text02) ? "right" : "wrong") << endl;
	cout << text02 << ": " << (test(text02) ? "right" : "wrong") << endl;


	const char* text03 = "( ( [ { } [ ] ( [ ] ) ] ) )   OK";
	cout << text03 << ": " << (testBalanceBrackets(text03) ? "right" : "wrong") << endl;
	cout << text03 << ": " << (test(text03) ? "right" : "wrong") << endl;

	const char* text04 = "( ( [ { } [ ] ( [ ] ) ] ) )  ) extra right parenthesis ";
	cout << text04 << ": " << (testBalanceBrackets(text04) ? "right" : "wrong") << endl;
	cout << text04 << ": " << (test(text04) ? "right" : "wrong") << endl;

	const char* text05 = "( ( [{ }[ ]([ ])] )  extra left  parenthesis ";
	cout << text05 << ": " << (testBalanceBrackets(text05) ? "right" : "wrong") << endl;
	cout << text05 << ": " << (test(text05) ? "right" : "wrong") << endl;

	const char* text06 = "( ( [{ ][ ]([ ])]) ) unpaired bracket ";
	cout << text06 << ": " << (testBalanceBrackets(text06) ? "right" : "wrong") << endl;
	cout << text06 << ": " << (test(text06) ? "right" : "wrong") << endl;
	
	



	return 0;


}