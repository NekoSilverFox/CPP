#include<iostream>
#include<cstring>
#include<algorithm> 
#include<stack>
#include"Operator.h"
using namespace std;


int main()
{
	Operation test;
	test.initial();
	cout << test.toPost()<<endl;
	test.calculate();
	return 0;
}