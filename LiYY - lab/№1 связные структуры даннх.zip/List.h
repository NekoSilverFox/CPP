#pragma once
#include<iostream>

//----------------------------------------------Node-------------------------------------------------------------
struct Node
{
	int val;
	Node* next;

	Node() :next(nullptr){ }
	Node(int s):next(nullptr),val(s){}

};


//-----------------------------------------------List-------------------------------------------------------------

using namespace std;

class List
{
public:
	Node* head;
	int size;


	List() :size(0) { head = new Node; head->next = nullptr; }
	List(Node* h, int s) :head(h), size(s) { }
	List(List& list)				
		:head(list.head),size(list.size)
	{ }
	List(List&& list2)				//move constor
		: size(list2.size)
	{
		cout << "Move constructor called/n";
		head = list2.head;
		list2.head = nullptr;
		list2.size = 0;
	}
	~List()							
	{
		if (head == nullptr || head->next == nullptr)
		{
			delete head;
			head = nullptr;
			return;
		}
		Node* pCurrent = head;
		Node* pNext = head->next;


		while (pNext != nullptr && pCurrent != nullptr)
		{
			delete  pCurrent;
			pCurrent = nullptr;
			pCurrent = pNext;
			pNext = pNext->next;
		}
		head = nullptr;
	}

	bool isPresent(int s);	//if int s in the list,return true,else false
	void select();			//select the list from small to big
	void operator+=(int s);	//add element to the list
	void print()			
	{
		Node* p;
		p = head->next;
		while (p)
		{
			cout << p->val << " ";
			p = p->next;
		}
	}
	friend ostream& operator<<(ostream& os,Node* p);
	bool operator==(List& listB)const;	//compare two list
	void operator=(List& listB)			
	{
		head = listB.head;
		size = listB.size;
	}

	
	friend List& operator&(List& listA, List& listB);	//creat the insection of list A and B( C=A&B )
	friend List& operator|(List& listA, List& listB);	//creat the union of list A and B (C=A|B )
	
	List& merge(List& listB);	//add element to list,which are contained in listB
	
};


bool List::isPresent(int s)
{
	bool isPre = false;
	Node* p = head->next;
	if (!p)
	{
		cout << "No Node in the list\n";
		return isPre;
	}
	while (p)
	{
		if (p->val == s)
		{
			isPre = true;
			break;
		}
		p = p->next;
	}
	return isPre;
}

void List::select()							//bubble sort
{
	int count = size;

	Node* pMove = head->next;

	//��������Ϊcount-1
	while (count > 1) {
		while (pMove->next != NULL) {
			if (pMove->val > pMove->next->val) {
				int temp= pMove->val;
				pMove->val = pMove->next->val;
				pMove->next->val = temp;
			}
			pMove = pMove->next;
		}
		count--;
		//�����ƶ�����һ���ڵ�
		pMove = head->next;
	}
	//cout << "select succeed\n";
}

void List::operator+=(int s)
{
	Node* r = new Node(s);
	r->next = head->next;
	head->next = r;
	size++;
}



ostream& operator<<(ostream& os, List& list)
{
	Node* p;
	p = list.head->next;
	while (p)
	{
		cout << p->val << "	";
		p = p->next;
	}
	return os;

}


bool List::operator==(List& listB)const
{
	if (this->size != listB.size)
		return false;
	
	if (!this->head->next || !listB.head->next)		//if the list is empty
		return false;

	Node* pA = this->head->next;
	Node* pB = listB.head->next;
	bool isEqual = true;
	while (pA)
	{
		if (pA->val != pB->val)
			isEqual = false;
		pA = pA->next;
		pB = pB->next;
	}
	return isEqual;
}



List& operator&(List& A, List& B)			
{

	/*
		�ҵ����������Ľ���												find the insection of the list
		���α��������������Ƚ�����������ǰԪ�صĴ�С��ϵ						
		1���������������ǰԪ����ȣ����ҵ�һ���ཻԪ��
		2�������һ������Ԫ��С�ڵڶ�������Ԫ�أ����һ��������ָ�����һλ
		3�������һ������Ԫ�ش��ڵڶ�������Ԫ�أ���ڶ���������ָ�����һλ
	*/
	A.select();
	B.select();
	int count=0;
	List* pC = new List;
	Node* p, * q;
	p = A.head->next;
	q = B.head->next;
	if (p == nullptr || q == nullptr)		//if list empty,return empty list
	{
		cout << "Empty list\n";
		return *pC;
	}
	while (p != nullptr && q != nullptr)
	{
		if (p->val < q->val)
		{
			p = p->next;
		}
		else if (p->val == q->val)
		{

			*pC += q->val;
			count++;

			p = p->next;
			q = q->next;
		}
		else
		{
			q = q->next;
		}
	}
	pC->size = count;
	pC->select();
	return *pC;

}


List& operator|(List& A, List& B)
{
	/*
	1.��A�е�Ԫ��ȫ�����뵽�ձ���
	2.����B�е�Ԫ�أ�������±�û�У���ô�������
	3.�����±�
	*/
	A.select();
	B.select();
	
	int count = 0;
	List* pC = new List;
	Node* pA, * pB;
	pA = A.head->next;
	pB = B.head->next;

	while (pA)			
	{
		*pC += pA->val;
		count++;
		pA = pA->next;
	}
	while (pB)
	{
		if (!(pC->isPresent(pB->val)))	//if the element in B is NOT included in C,then add it
		{
			*pC += pB->val;
			count++;
		}
		pB = pB->next;
	}
	pC->size = count;
	pC->select();
	return *pC;
}

List& List::merge(List& B)
{
	Node* pB = B.head->next;
	Node* pA = this->head->next;
	if (!pB)
	{
		cout<< "Empty List\n";
		return *this;
	}
	while (pB)		//if the elem in B is included in A,then break; else add it to A
	{
		pA = this->head->next;
		while (pA)
		{
			if (this->isPresent(pB->val))
				break;
			else
			{
				this->operator+=(pB->val);
			}
			pA = pA->next;
		}
		pB = pB->next;
	}
	this->select();
	cout << "merge over.\n";
	return *this;
}

