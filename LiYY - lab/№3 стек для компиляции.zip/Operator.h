#pragma once

#include<iostream>
#include<cstring>
#include<algorithm>		
#include<stack>
#include <string>
using namespace std;

// Operator.h
// Operator -> class , where can turn infix to post

//numbers can only be 0-9,no more
//oparators are limited in +-*/^


class Operation
{

public:
	stack<char> oper;	//stack for operator +-*/^()
	string exp;			//expretion infix
	string postExp;

private:
	bool isOper(char);
	int prior(char);	//numbers have the highest prior
public:
	Operation(){ }
	~Operation(){ }
	void initial();
	string toPost();
	void getPost() {cout << postExp; }
	int calculate();

};

bool Operation:: isOper(char c)
{
	if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^' ||c=='('||c==')' )
		return true;
	else
	{
		return false;
	}
}

int Operation:: prior(char c)	//�����ǲ���Ӧ���ж�һ�´���
{
	
		switch (c)
		{
		case'(':
			return -1;
			break;
		case '+':
		case '-':
			return 1;
			break;
		case '*':
		case '/':
			return 2;
			break;
		case '^':
			return 3;
			break;
		}
	//}

}


void Operation::initial()
{
	string expr;
	cout << "Enter expretion infix:\n";
	getline(cin, expr);
	exp = expr;
	cout << "infix settled : " << exp <<endl;

}

string Operation:: toPost()		//set infix to post
{
	string result;			//������¼��׺����ʽ
	for (unsigned int i = 0; i < exp.length(); ++i)
	{
		char c = exp[i];

		if (c == ' ')					//read spell
			continue;

		if (!isOper(c))					//if it is a number
		{
			result += c;
		}
		else if (c == '(')				//is '(' �д���
		{
			oper.push(c);				//push (
		}
		else if (c == ')')				//is ')'
		{
			while ( (!oper.empty()) && (oper.top() != '(') )	//pop operator stack UNTIL the top is '('
			{
				char tmp = oper.top();
				result += tmp;
				oper.pop();
			}
			oper.pop();					//pop the (
			
		}
		else							//is '+''��' '*' '/' '^'
		{
			if (oper.empty())			//if operator stack empty, push it
			{
				oper.push(c);

			}
			else						//if not empty, compare the prior
			{
				if (prior(c) <= prior(oper.top()))		//if current operator's prior is not higher than top, pop
				{
					while (!oper.empty() && prior(c) <= prior( oper.top() ))
					{
						char tmp = oper.top();
						result += tmp;
						oper.pop();
					}
					oper.push(c);

				}
				else                     //if higher , then push it into operator stack
				{
					oper.push(c);

				}
			}
		}
	}
	cout << "Indix to Post finished:\n";
	while (!oper.empty() )					//����ջ��ʣ��Ԫ�� 
	{				
		result += oper.top();
		oper.pop();
	}
	postExp = result;
	return result;
}

int Operation::calculate()
{
		stack<int> result;
		string s = postExp;
		for (unsigned int i = 0; i < s.length(); i++)
		{
			if (!isOper(s[i]))
			{
				result.push( s[i] - '0' );		//switch to number
			}
			else
			{
				int temp2 = result.top();
				result.pop();
				int temp1 = result.top();
				result.pop();
				if (s[i] == '+')
				{
					result.push(temp1 + temp2);
				}
				else if (s[i] == '-')
				{
					result.push(temp1 - temp2);
				}
				else if (s[i] == '*')
				{
					result.push(temp1 * temp2);
				}
				else if (s[i] == '/')
				{
					result.push(temp1 / temp2);
				}
				else if (s[i] =='^')
				{
					//result.push(temp1 ^ temp2);
					int left = temp1;
					int right = temp2;
					int fin=left;
					for (int i = 1; i < right; i++)
					{
						fin *= left;
					}
					cout << "fin = " << fin << endl;
					result.push(fin);
				}
			}
		}
		cout << "Result: " << result.top() << endl;
		return result.top();
}